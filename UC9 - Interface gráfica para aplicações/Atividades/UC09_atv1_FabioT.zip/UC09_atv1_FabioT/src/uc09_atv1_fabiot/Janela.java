
package uc09_atv1_fabiot;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Janela {

   
    public static void main(String[] args) {
        
        JFrame janela = new JFrame();
        janela.setSize(500, 300);
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        janela.setTitle("Atividade 1 - Valor e desconto");
        janela.setLayout(new FlowLayout());
        janela.setLocationRelativeTo(null); // centralizar
        
        JLabel rotulo = new JLabel();
        rotulo.setText("Insira o valor da venda (R$):");
        janela.add(rotulo);
        
        JTextField campo = new JTextField(15);
        janela.add(campo);
        
        JButton botao = new JButton();
        botao.setText("Calcular");
        janela.add(botao);
        
        botao.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                
                // 1) Lê e valida o valor da venda
                double valor;
                try {
                    // trim() para ajustar decimais e 'replace' para aceitar vírgula ou ponto.
                    valor = Double.parseDouble(campo.getText().trim().replace(",", "."));
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(janela,
                            "Digite apenas números. Exemplo: 650 ou 650,90",
                            "Valor inválido", JOptionPane.ERROR_MESSAGE);
                    campo.requestFocus();
                    return;
                }

                if (valor <= 0) {
                    JOptionPane.showMessageDialog(janela,
                            "O valor da venda deve ser maior que zero.",
                            "Valor inválido", JOptionPane.ERROR_MESSAGE);
                    campo.requestFocus();
                    return;
                }

                double desconto = 0;

                // 2) Para valor acima de 500, pedir percentual de desconto
                if (valor > 500) {
                    boolean valido = false;
                    while (!valido) {
                        String resposta = JOptionPane.showInputDialog(janela,
                                "Venda acima de R$ 500,00.\nInforme o percentual de desconto (0 a 100):",
                                "Desconto", JOptionPane.QUESTION_MESSAGE);

                        if (resposta == null) { // clicou em Cancelar ou fechou
                            return;
                        }
                        try {
                            desconto = Double.parseDouble(resposta.trim().replace(",", "."));
                            if (desconto >= 0 && desconto <= 100) {
                                valido = true;
                            } else {
                                JOptionPane.showMessageDialog(janela,
                                        "O desconto deve estar entre 0 e 100.",
                                        "Desconto inválido", JOptionPane.ERROR_MESSAGE);
                            }
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(janela,
                                    "Digite apenas números. Exemplo: 10",
                                    "Desconto inválido", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }

                // 3) Calcula e mostra o total
                double total = valor - (valor * desconto / 100);
                String mensagem = String.format(
                        "Valor da venda: R$ %.2f\nDesconto: %.2f%%\nTotal a pagar: R$ %.2f",
                        valor, desconto, total);
                JOptionPane.showMessageDialog(janela, mensagem,
                        "Total da venda", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        janela.setVisible(true);
    }
}
 
    

